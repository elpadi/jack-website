-- MySQL dump 10.13  Distrib 5.5.34, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: dahlen_jack
-- ------------------------------------------------------
-- Server version	5.5.34-0ubuntu0.12.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `jack_invites`
--

DROP TABLE IF EXISTS `jack_invites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jack_invites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `hash` varchar(32) NOT NULL,
  `additional` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `hash` (`hash`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jack_invites`
--

LOCK TABLES `jack_invites` WRITE;
/*!40000 ALTER TABLE `jack_invites` DISABLE KEYS */;
INSERT INTO `jack_invites` VALUES (1,'carlos@el-cajon','83424ced3e5c174343738984a4c8cddb','hey baby\r\n');
/*!40000 ALTER TABLE `jack_invites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jack_invites_sent`
--

DROP TABLE IF EXISTS `jack_invites_sent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jack_invites_sent` (
  `invite_id` int(11) NOT NULL,
  `time` datetime NOT NULL,
  KEY `invite_id` (`invite_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jack_invites_sent`
--

LOCK TABLES `jack_invites_sent` WRITE;
/*!40000 ALTER TABLE `jack_invites_sent` DISABLE KEYS */;
INSERT INTO `jack_invites_sent` VALUES (1,'2013-12-22 16:06:04'),(1,'2013-12-22 16:06:57'),(1,'2013-12-22 16:07:25'),(1,'2013-12-22 16:11:12'),(1,'2013-12-22 16:11:42'),(1,'2013-12-22 16:12:15'),(1,'2013-12-22 16:16:07'),(1,'2013-12-22 16:19:05'),(1,'2013-12-22 16:19:36'),(1,'2013-12-22 16:25:01'),(1,'2013-12-22 16:27:00'),(1,'2013-12-22 16:28:19'),(1,'2013-12-22 16:35:41');
/*!40000 ALTER TABLE `jack_invites_sent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jack_invites_uses`
--

DROP TABLE IF EXISTS `jack_invites_uses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jack_invites_uses` (
  `invite_id` int(11) NOT NULL,
  `time` datetime NOT NULL,
  KEY `invite_id` (`invite_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jack_invites_uses`
--

LOCK TABLES `jack_invites_uses` WRITE;
/*!40000 ALTER TABLE `jack_invites_uses` DISABLE KEYS */;
/*!40000 ALTER TABLE `jack_invites_uses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jack_issue_posters`
--

DROP TABLE IF EXISTS `jack_issue_posters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jack_issue_posters` (
  `issue_id` int(11) NOT NULL,
  `poster_id` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`issue_id`,`poster_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jack_issue_posters`
--

LOCK TABLES `jack_issue_posters` WRITE;
/*!40000 ALTER TABLE `jack_issue_posters` DISABLE KEYS */;
INSERT INTO `jack_issue_posters` VALUES (1,1,-5),(1,2,-6),(1,3,-4),(1,4,-3),(1,5,-2),(1,6,0);
/*!40000 ALTER TABLE `jack_issue_posters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jack_issues`
--

DROP TABLE IF EXISTS `jack_issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jack_issues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL,
  `slug` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jack_issues`
--

LOCK TABLES `jack_issues` WRITE;
/*!40000 ALTER TABLE `jack_issues` DISABLE KEYS */;
INSERT INTO `jack_issues` VALUES (1,'Spring 2014','spring-2014');
/*!40000 ALTER TABLE `jack_issues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jack_posters`
--

DROP TABLE IF EXISTS `jack_posters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jack_posters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL,
  `slug` varchar(64) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jack_posters`
--

LOCK TABLES `jack_posters` WRITE;
/*!40000 ALTER TABLE `jack_posters` DISABLE KEYS */;
INSERT INTO `jack_posters` VALUES (1,'Madonna White Overall','','Madonna wearing a white overall by a wooden wall.'),(2,'Madonna Black Sheer','madonna-black-sheer','Madonna in a black sheer top and black trousers.'),(3,'Scissor Sisters Mirror','scissor-sisters-mirror','Yes, he is licking his reflection\'s tongue.'),(4,'Scissor Sisters LoveMe','scissor-sisters-loveme','Posing in front of a neon \"love me\" sign.'),(5,'Nighties','nighties','Bunch of girls in nighties.'),(6,'Two Ladies','two-ladies','Two ladies modeling in a dark room.');
/*!40000 ALTER TABLE `jack_posters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ul_blocked_ips`
--

DROP TABLE IF EXISTS `ul_blocked_ips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ul_blocked_ips` (
  `ip` varchar(39) CHARACTER SET ascii NOT NULL,
  `block_expires` varchar(26) CHARACTER SET ascii NOT NULL,
  PRIMARY KEY (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ul_blocked_ips`
--

LOCK TABLES `ul_blocked_ips` WRITE;
/*!40000 ALTER TABLE `ul_blocked_ips` DISABLE KEYS */;
/*!40000 ALTER TABLE `ul_blocked_ips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ul_log`
--

DROP TABLE IF EXISTS `ul_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ul_log` (
  `timestamp` varchar(26) CHARACTER SET ascii NOT NULL,
  `action` varchar(20) CHARACTER SET ascii NOT NULL,
  `comment` varchar(255) CHARACTER SET ascii NOT NULL DEFAULT '',
  `user` varchar(400) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(39) CHARACTER SET ascii NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ul_log`
--

LOCK TABLES `ul_log` WRITE;
/*!40000 ALTER TABLE `ul_log` DISABLE KEYS */;
INSERT INTO `ul_log` VALUES ('2013-11-03T23:05:35-05:00','auth-fail','','carlos@carlos.com','127.0.0.1'),('2013-11-03T23:24:19-05:00','create login','','padi_05@yahoo.com','127.0.0.1'),('2013-11-03T23:25:43-05:00','auth-success','','padi_05@yahoo.com','127.0.0.1'),('2013-11-03T23:27:38-05:00','auth-success','','padi_05@yahoo.com','127.0.0.1'),('2013-11-03T23:31:50-05:00','auth-success','','padi_05@yahoo.com','127.0.0.1'),('2013-11-04T22:52:56-05:00','auth-fail','','padi_05@yahoo.com','127.0.0.1'),('2013-11-04T22:53:04-05:00','auth-fail','','padi_05@yahoo.com','127.0.0.1'),('2013-11-04T22:53:24-05:00','auth-success','','padi_05@yahoo.com','127.0.0.1'),('2013-12-22T19:47:33-05:00','create login','','invited-guest@thejackmag.com','127.0.0.1'),('2013-12-22T20:29:56-05:00','auth-success','','invited-guest@thejackmag.com','127.0.0.1'),('2013-12-22T20:34:06-05:00','auth-success','','invited-guest@thejackmag.com','127.0.0.1'),('2013-12-22T20:34:55-05:00','auth-success','','invited-guest@thejackmag.com','127.0.0.1'),('2013-12-22T20:36:12-05:00','auth-success','','invited-guest@thejackmag.com','127.0.0.1');
/*!40000 ALTER TABLE `ul_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ul_logins`
--

DROP TABLE IF EXISTS `ul_logins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ul_logins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(400) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(2048) CHARACTER SET ascii NOT NULL,
  `date_created` varchar(26) CHARACTER SET ascii NOT NULL,
  `last_login` varchar(26) CHARACTER SET ascii NOT NULL,
  `block_expires` varchar(26) CHARACTER SET ascii NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`(255))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ul_logins`
--

LOCK TABLES `ul_logins` WRITE;
/*!40000 ALTER TABLE `ul_logins` DISABLE KEYS */;
INSERT INTO `ul_logins` VALUES (1,'padi_05@yahoo.com','$2a$11$wyBHv6pr4F.Xv/DnAXKrt.p1rTFiqFTPZJVs8OYwj8GKJNY..qSAu','2013-11-03T23:24:19-05:00','2013-11-04T22:53:24-05:00','1013-11-03T23:24:19-05:00'),(2,'invited-guest@thejackmag.com','$2a$11$vzkwBCIejXtzIqcYLf2rSOuENBpHEzPKqwr31Q557X0vtJqgohVzS','2013-12-22T19:47:33-05:00','2013-12-22T20:36:12-05:00','1013-12-22T19:47:33-05:00');
/*!40000 ALTER TABLE `ul_logins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ul_nonces`
--

DROP TABLE IF EXISTS `ul_nonces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ul_nonces` (
  `code` varchar(100) CHARACTER SET ascii NOT NULL,
  `action` varchar(850) CHARACTER SET ascii NOT NULL,
  `nonce_expires` varchar(26) CHARACTER SET ascii NOT NULL,
  PRIMARY KEY (`code`),
  UNIQUE KEY `action` (`action`(255))
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ul_nonces`
--

LOCK TABLES `ul_nonces` WRITE;
/*!40000 ALTER TABLE `ul_nonces` DISABLE KEYS */;
INSERT INTO `ul_nonces` VALUES ('be424b63deabfdb966f745394c077af2f3ae4922c60fd63c64083e5b6af7042c','padi_05@yahoo.com-autologin','2014-01-05T22:53:24-05:00'),('d4bd40d2a7c058073bd2fadc3d6196a57b7ec4bbfae2acbd9c26e9446ec97353','invited-guest@thejackmag.com-autologin','2014-02-22T20:36:12-05:00');
/*!40000 ALTER TABLE `ul_nonces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ul_sessions`
--

DROP TABLE IF EXISTS `ul_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ul_sessions` (
  `id` varchar(128) CHARACTER SET ascii NOT NULL DEFAULT '',
  `data` blob NOT NULL,
  `session_expires` varchar(26) CHARACTER SET ascii NOT NULL,
  `lock_expires` varchar(26) CHARACTER SET ascii NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ul_sessions`
--

LOCK TABLES `ul_sessions` WRITE;
/*!40000 ALTER TABLE `ul_sessions` DISABLE KEYS */;
INSERT INTO `ul_sessions` VALUES ('0b1ote0q4mqohes1t0hhntnqc3','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:24:\"localhost.thejackmag.com\";s:9:\"userAgent\";s:74:\"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:25.0) Gecko/20100101 Firefox/25.0\";s:7:\"EXPIRES\";i:1385671526;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"bd0091e90afa4c1a9bb6936398b34e0d15006e2f22f0dbc1d11797b5725953d3\";s:6:\"expire\";s:25:\"2013-11-28T15:45:26-05:00\";}}slim.flash|a:0:{}','2013-11-28T15:49:26-05:00','1013-11-28T15:25:26-05:00'),('0crj4mrel5v384m2187634h4l6','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:74:\"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:25.0) Gecko/20100101 Firefox/25.0\";s:7:\"EXPIRES\";i:1385430473;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"38bbd6a2ae508a98ab7e980f0f84ae66a8a1181d7233a6dfaeef457354ae8fd5\";s:6:\"expire\";s:25:\"2013-11-25T20:47:53-05:00\";}}slim.flash|a:0:{}','2013-11-25T20:51:53-05:00','1013-11-25T20:27:53-05:00'),('0dg5hbli6t51oq0fajfk8jgni6','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:24:\"localhost.thejackmag.com\";s:9:\"userAgent\";s:131:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/31.0.1650.63 Chrome/31.0.1650.63 Safari/537.36\";s:7:\"EXPIRES\";i:1387066589;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"3774e5d85385ce382e53dbf86ce7ccbde20c1dde50f1afafe46087f25433aac3\";s:6:\"expire\";s:25:\"2013-12-14T19:16:29-05:00\";}}','2013-12-14T19:20:29-05:00','1013-12-14T18:56:29-05:00'),('15fpjbciligvvt5niah5fv0u73','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:74:\"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:25.0) Gecko/20100101 Firefox/25.0\";s:7:\"EXPIRES\";i:1385943222;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"76de7ddd777012b542a9211ffbfc057bf61d08ab8f1d908ee350f2bf228d2663\";s:6:\"expire\";s:25:\"2013-12-01T19:13:42-05:00\";}}slim.flash|a:0:{}','2013-12-01T19:17:42-05:00','1013-12-01T18:53:42-05:00'),('26k2d0tu14sr13er7slgm89o30','sses|a:4:{s:9:\"IPaddress\";s:11:\"192.168.1.4\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:81:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:25.0) Gecko/20100101 Firefox/25.0\";s:7:\"EXPIRES\";i:1385937782;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"8f6cb8b63fc88b640807d2ea2faee62ac52d70c2f4bcac2a6fcd0087f928f3a3\";s:6:\"expire\";s:25:\"2013-12-01T17:43:02-05:00\";}}slim.flash|a:0:{}','2013-12-01T17:47:02-05:00','1013-12-01T17:23:02-05:00'),('2qn7vpbm6iaccaov4mel4rvfb3','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:131:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/31.0.1650.63 Chrome/31.0.1650.63 Safari/537.36\";s:7:\"EXPIRES\";i:1386908741;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"ad64894b1803b8045479bbe5596d8c1a89b95892b57d0d1e85ffdb1d82f07328\";s:6:\"expire\";s:25:\"2013-12-12T23:25:41-05:00\";}}slim.flash|a:0:{}','2013-12-12T23:29:41-05:00','1013-12-12T23:05:41-05:00'),('4fqjvuupfdl418n3aipvof1pf3','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:74:\"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:25.0) Gecko/20100101 Firefox/25.0\";s:7:\"EXPIRES\";i:1385091775;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"524cffe29192bfa5a817d0f22fe99b96d4f0036f7d8cf85a7a16bb6734d14bdc\";s:6:\"expire\";s:25:\"2013-11-21T22:42:55-05:00\";}}slim.flash|a:0:{}','2013-11-21T22:46:55-05:00','1013-11-21T22:22:55-05:00'),('4l497s560hf9trt16aaj9qpqp3','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:131:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/31.0.1650.63 Chrome/31.0.1650.63 Safari/537.36\";s:7:\"EXPIRES\";i:1387763631;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"9fbff982dc5bb332ffb2fe96836229dbf19ea1e616020738a04d96d3dea582e4\";s:6:\"expire\";s:25:\"2013-12-22T20:53:51-05:00\";}}slim.flash|a:0:{}','2013-12-22T20:57:51-05:00','1013-12-22T20:33:51-05:00'),('6di80f7a9vdp17iu6cqr73k5n1','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:74:\"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:25.0) Gecko/20100101 Firefox/25.0\";s:7:\"EXPIRES\";i:1385943099;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"9a7bf5e82d3900afdbd5b6096383707845e1a7c5fe957ccf2e358f55c0b7bd86\";s:6:\"expire\";s:25:\"2013-12-01T19:11:39-05:00\";}}slim.flash|a:0:{}','2013-12-01T19:15:39-05:00','1013-12-01T18:51:39-05:00'),('6u4nvsgj3kcjcvrpo6eoodc9m7','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:24:\"localhost.thejackmag.com\";s:9:\"userAgent\";s:74:\"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:25.0) Gecko/20100101 Firefox/25.0\";s:7:\"EXPIRES\";i:1385439969;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"7c74326eb02b129dd34853401dbe9db4ca492df67648732603f0f9511ee27468\";s:6:\"expire\";s:25:\"2013-11-25T23:26:09-05:00\";}}slim.flash|a:0:{}','2013-11-25T23:30:09-05:00','1013-11-25T23:06:09-05:00'),('73uvirveangl025pe95vibdjv5','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:74:\"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:25.0) Gecko/20100101 Firefox/25.0\";s:7:\"EXPIRES\";i:1386305408;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"e24b7f1cb37ecc59bc1c223d65ad8e8c27c499f6dea51afb75702beed4f1d638\";s:6:\"expire\";s:25:\"2013-12-05T23:50:08-05:00\";}}slim.flash|a:0:{}','2013-12-05T23:54:08-05:00','1013-12-05T23:30:08-05:00'),('7i4lr9a4jk2mtbqccsqp2mfnk6','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:74:\"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:25.0) Gecko/20100101 Firefox/25.0\";s:7:\"EXPIRES\";i:1385667694;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"58e2031a6e227a32571f5c3eaa0272e16ce111aa34f4b06fb2789ce52da4dfb7\";s:6:\"expire\";s:25:\"2013-11-28T14:41:34-05:00\";}}slim.flash|a:0:{}','2013-11-28T14:45:34-05:00','1013-11-28T14:21:34-05:00'),('8arb4e2kn133pipbd4u5oe7a23','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:74:\"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:24.0) Gecko/20100101 Firefox/24.0\";s:7:\"EXPIRES\";i:1384708419;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"48201b4d04a8ced20d2e9f113f8f3683658dbe0bba013ea6c2146f7734b12352\";s:6:\"expire\";s:25:\"2013-11-17T12:13:39-05:00\";}}slim.flash|a:0:{}','2013-11-17T12:17:39-05:00','1013-11-17T11:53:39-05:00'),('8mk8iso2e7klvh5br9mc9eu606','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:74:\"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:26.0) Gecko/20100101 Firefox/26.0\";s:7:\"EXPIRES\";i:1387608406;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"06c16e4745f2d484cfb700c5f1ea7904cf6c5a4c39db3c77e9e50c7f3f37087b\";s:6:\"expire\";s:25:\"2013-12-21T01:46:46-05:00\";}}slim.flash|a:0:{}','2013-12-21T01:50:46-05:00','1013-12-21T01:26:46-05:00'),('8prb7voh7lkp05nn546sddbvo2','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:131:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/28.0.1500.71 Chrome/28.0.1500.71 Safari/537.36\";s:7:\"EXPIRES\";i:1384491884;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"45affa5addbf63fde654351342919eb746a7a050b1d88d12ef3a68c670c0fbee\";s:6:\"expire\";s:25:\"2013-11-15T00:04:44-05:00\";}}slim.flash|a:0:{}','2013-11-15T00:08:44-05:00','1013-11-14T23:44:44-05:00'),('8u6cr84ntqrrdbkg3765t0jug4','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:74:\"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:25.0) Gecko/20100101 Firefox/25.0\";s:7:\"EXPIRES\";i:1385171752;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"70d2a3f08664320cac09162b74531dff4e3a89fa1ad22d4dfe33a0f32b2002bb\";s:6:\"expire\";s:25:\"2013-11-22T20:55:52-05:00\";}}slim.flash|a:0:{}','2013-11-22T20:59:52-05:00','1013-11-22T20:35:52-05:00'),('8v56eqt5gduadil4t460g39n02','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:74:\"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:25.0) Gecko/20100101 Firefox/25.0\";s:7:\"EXPIRES\";i:1385096974;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"86a7e09c7dcb04ff790cb92db2bc0bb4054e86e79909e82986e8a0e6d967a232\";s:6:\"expire\";s:25:\"2013-11-22T00:09:34-05:00\";}}slim.flash|a:0:{}','2013-11-22T00:13:34-05:00','1013-11-21T23:49:34-05:00'),('90j3kj2bavoj1q5a9ilg1okpd4','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:74:\"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:25.0) Gecko/20100101 Firefox/25.0\";s:7:\"EXPIRES\";i:1384999178;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"984e2dec1bfece903658222fb5d86e4c2034fe6385cfcd0e8957233f3117e52a\";s:6:\"expire\";s:25:\"2013-11-20T20:59:38-05:00\";}}slim.flash|a:0:{}','2013-11-20T21:03:38-05:00','1013-11-20T20:39:38-05:00'),('9m2q2osvt03mn0c4er12j2okg1','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:131:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/31.0.1650.63 Chrome/31.0.1650.63 Safari/537.36\";s:7:\"EXPIRES\";i:1387853733;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"b6278bf639c182fe045fcfc4b058e6135d86f87577c06f9c7435f38b30cb0f36\";s:6:\"expire\";s:25:\"2013-12-23T21:55:33-05:00\";}}slim.flash|a:0:{}','2013-12-23T21:59:33-05:00','1013-12-23T21:35:33-05:00'),('a9t1fs1p6ivqkf26hkk4301sj1','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:74:\"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:26.0) Gecko/20100101 Firefox/26.0\";s:7:\"EXPIRES\";i:1387768670;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"b69bc8f1f56c176f0994b58f6fd0fe6c2420fbee7bf5807abb9ebb72327688d4\";s:6:\"expire\";s:25:\"2013-12-22T22:17:50-05:00\";}}slim.flash|a:0:{}','2013-12-22T22:21:50-05:00','1013-12-22T21:57:50-05:00'),('bi7ki7gtjrciiorjdlbovtflt1','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:131:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/28.0.1500.71 Chrome/28.0.1500.71 Safari/537.36\";s:7:\"EXPIRES\";i:1383540724;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"2f78886d48232ae6e106d995f4da857cb812fe9fc75fc8d36b6cb55af86a08eb\";s:6:\"expire\";s:25:\"2013-11-03T23:52:04-05:00\";}}slim.flash|a:0:{}uid|i:1;username|s:17:\"padi_05@yahoo.com\";loggedIn|b:1;','2013-11-03T23:56:04-05:00','1013-11-03T23:32:04-05:00'),('gvqca3d6gipff08p6mq894ku52','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:74:\"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:25.0) Gecko/20100101 Firefox/25.0\";s:7:\"EXPIRES\";i:1386305406;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"27b18bf9f8a90f7c9df07422d2586439773cbb1b6ba6fc583b02296a75330040\";s:6:\"expire\";s:25:\"2013-12-05T23:50:06-05:00\";}}slim.flash|a:0:{}','2013-12-05T23:54:06-05:00','1013-12-05T23:30:06-05:00'),('h7vrie1offn0b785032m0qh9u7','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:74:\"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:24.0) Gecko/20100101 Firefox/24.0\";s:7:\"EXPIRES\";i:1384708420;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"7f1adeccefa9c1771f508e506873fd146eae7cbb85d534782e145777cbb277e4\";s:6:\"expire\";s:25:\"2013-11-17T12:13:40-05:00\";}}slim.flash|a:0:{}','2013-11-17T12:17:39-05:00','1013-11-17T11:53:40-05:00'),('hst1h5u58q2fk6t0nennfe0vn4','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:24:\"localhost.thejackmag.com\";s:9:\"userAgent\";s:133:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/30.0.1599.114 Chrome/30.0.1599.114 Safari/537.36\";s:7:\"EXPIRES\";i:1386562989;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"00f802f26516cb70310fb7a86cce9ffd42c0fcb6c9ba777cbe1e3b9c4723ee50\";s:6:\"expire\";s:25:\"2013-12-08T23:23:09-05:00\";}}slim.flash|a:0:{}','2013-12-08T23:27:09-05:00','1013-12-08T23:03:09-05:00'),('i5mjp5hmrajbgke5gclk964043','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:131:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/28.0.1500.71 Chrome/28.0.1500.71 Safari/537.36\";s:7:\"EXPIRES\";i:1384229695;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"c8b886b966160f034f128d3e275f4eb8e73132c6f0293bc3dfd65219f90f7ab5\";s:6:\"expire\";s:25:\"2013-11-11T23:14:55-05:00\";}}slim.flash|a:0:{}','2013-11-11T23:18:55-05:00','1013-11-11T22:54:55-05:00'),('ie34v8coh2airlmibdodes2th0','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:24:\"localhost.thejackmag.com\";s:9:\"userAgent\";s:131:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/31.0.1650.63 Chrome/31.0.1650.63 Safari/537.36\";s:7:\"EXPIRES\";i:1387088116;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"9cc60fbbf2eb673dea6319f4ab12429b125bd7c0589a01fffbbbac218524a79d\";s:6:\"expire\";s:25:\"2013-12-15T01:15:16-05:00\";}}slim.flash|a:0:{}','2013-12-15T01:19:16-05:00','1013-12-15T00:55:16-05:00'),('iejd3utgp4n7k5jkn1s22kdu07','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:133:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/30.0.1599.114 Chrome/30.0.1599.114 Safari/537.36\";s:7:\"EXPIRES\";i:1384835745;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"fd54fec345162ba7e2ebdfbeb36eea04ff6e19abbecd67579e6323f0a40de363\";s:6:\"expire\";s:25:\"2013-11-18T23:35:45-05:00\";}}slim.flash|a:0:{}','2013-11-18T23:39:45-05:00','1013-11-18T23:15:45-05:00'),('inq1tpmj5m3b6o6kij1t1pek71','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:131:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/31.0.1650.63 Chrome/31.0.1650.63 Safari/537.36\";s:7:\"EXPIRES\";i:1387500317;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"f06c15f8913a19c4edaa9e9a8819600c450114b16d397f93b884363fbf8dfe07\";s:6:\"expire\";s:25:\"2013-12-19T19:45:17-05:00\";}}slim.flash|a:0:{}','2013-12-19T19:49:17-05:00','1013-12-19T19:25:17-05:00'),('iqobtoa4bm40i3ge60uoruo2b7','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:133:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/30.0.1599.114 Chrome/30.0.1599.114 Safari/537.36\";s:7:\"EXPIRES\";i:1385010760;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"1c2b16115dcfac5450307e46e9b23f44473a89b67b6370256f93c0a469684180\";s:6:\"expire\";s:25:\"2013-11-21T00:12:40-05:00\";}}slim.flash|a:0:{}','2013-11-21T00:16:40-05:00','1013-11-20T23:52:40-05:00'),('iubbsk9n72j245jckabl3a3ps0','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:131:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/31.0.1650.63 Chrome/31.0.1650.63 Safari/537.36\";s:7:\"EXPIRES\";i:1387600492;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"42d34d4f5cf6081a6b2dd435efd0c9a2f7a27d15031ab6dbc6777af13f27b758\";s:6:\"expire\";s:25:\"2013-12-20T23:34:52-05:00\";}}slim.flash|a:0:{}','2013-12-20T23:38:52-05:00','1013-12-20T23:14:52-05:00'),('jt06rf7v6lmrtu0lnjk9lu00p4','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:133:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/30.0.1599.114 Chrome/30.0.1599.114 Safari/537.36\";s:7:\"EXPIRES\";i:1385441171;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"13b35eb479f8a90c29e6fa702efe376b0a78eec62c6e8b900831e3ff8ca4340f\";s:6:\"expire\";s:25:\"2013-11-25T23:46:11-05:00\";}}slim.flash|a:0:{}','2013-11-25T23:50:11-05:00','1013-11-25T23:26:12-05:00'),('kjjan2nqjcvm3sl8p4qp4ui2g1','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:24:\"localhost.thejackmag.com\";s:9:\"userAgent\";s:131:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/31.0.1650.63 Chrome/31.0.1650.63 Safari/537.36\";s:7:\"EXPIRES\";i:1387777908;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"38d82f8b76fdbbf9edf3ec3fc5e828616cb600b6b884b2b88f8a84a07c2e5601\";s:6:\"expire\";s:25:\"2013-12-23T00:51:48-05:00\";}}slim.flash|a:0:{}','2013-12-23T00:55:48-05:00','1013-12-23T00:31:48-05:00'),('l4cs84m4snh8t92s54362p0ue4','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:131:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/28.0.1500.71 Chrome/28.0.1500.71 Safari/537.36\";s:7:\"EXPIRES\";i:1384491872;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"9f2333e0af8b7c35c896c71ceb883856c696032149c95c8b9d09c5559a885f79\";s:6:\"expire\";s:25:\"2013-11-15T00:04:32-05:00\";}}slim.flash|a:0:{}','2013-11-15T00:08:32-05:00','1013-11-14T23:44:32-05:00'),('l519r5n2bmqdr5nicie9bf3eb3','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:74:\"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:26.0) Gecko/20100101 Firefox/26.0\";s:7:\"EXPIRES\";i:1387514343;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"80d6f9ca92d4d77776d3ac05116d392b76452d3eb7622d3e8578a4298e75d5bd\";s:6:\"expire\";s:25:\"2013-12-19T23:39:03-05:00\";}}slim.flash|a:0:{}','2013-12-19T23:43:03-05:00','1013-12-19T23:19:04-05:00'),('leo8fdeuqainnmktruci5iplh2','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:133:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/30.0.1599.114 Chrome/30.0.1599.114 Safari/537.36\";s:7:\"EXPIRES\";i:1385669361;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"a020baa58fc98d27180d7b8359a261c420065f612a22a3a47df9b18727259ae6\";s:6:\"expire\";s:25:\"2013-11-28T15:09:21-05:00\";}}slim.flash|a:0:{}','2013-11-28T15:13:21-05:00','1013-11-28T14:49:21-05:00'),('lg03dbcj03cecbuld77rbukja4','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:74:\"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:25.0) Gecko/20100101 Firefox/25.0\";s:7:\"EXPIRES\";i:1385183575;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"10ac43539eaa285264afca122df47b0ccf5161fe76c4e2a6e5707b6c66207988\";s:6:\"expire\";s:25:\"2013-11-23T00:12:55-05:00\";}}slim.flash|a:0:{}','2013-11-23T00:16:55-05:00','1013-11-22T23:52:55-05:00'),('mp4172idffqnocjkht9s0jc3b2','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:131:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/28.0.1500.71 Chrome/28.0.1500.71 Safari/537.36\";s:7:\"EXPIRES\";i:1383625619;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"10f5780494894ee021ea69d4acf4595e307af7c8315f18244c4a70967d2d3550\";s:6:\"expire\";s:25:\"2013-11-04T23:26:59-05:00\";}}slim.flash|a:0:{}uid|i:1;username|s:17:\"padi_05@yahoo.com\";loggedIn|b:1;','2013-11-04T23:30:59-05:00','1013-11-04T23:06:59-05:00'),('mvj5da6dc0siuhn68biq6e11u6','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:24:\"localhost.thejackmag.com\";s:9:\"userAgent\";s:74:\"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:24.0) Gecko/20100101 Firefox/24.0\";s:7:\"EXPIRES\";i:1384748739;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"77e84c7d546af5e4d6a019585fd208bee07fe21842113d5b4ea0befa659bbfbe\";s:6:\"expire\";s:25:\"2013-11-17T23:25:39-05:00\";}}slim.flash|a:0:{}','2013-11-17T23:29:39-05:00','1013-11-17T23:05:39-05:00'),('p8pqor17n90vp300mgmu5sdlj1','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:131:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/31.0.1650.63 Chrome/31.0.1650.63 Safari/537.36\";s:7:\"EXPIRES\";i:1387763646;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"57d5b69762c538d883e870128068b5a9b7a9ffe08e3b35c8ea42149f7a1c0e5a\";s:6:\"expire\";s:25:\"2013-12-22T20:54:06-05:00\";}}slim.flash|a:0:{}uid|i:2;username|s:28:\"invited-guest@thejackmag.com\";loggedIn|b:1;','2013-12-22T20:58:06-05:00','1013-12-22T20:34:06-05:00'),('pbvprkd3fb01sph8p6nu4gour6','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:133:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/30.0.1599.114 Chrome/30.0.1599.114 Safari/537.36\";s:7:\"EXPIRES\";i:1386738916;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"3527fc627d692282cf3d1caafd76504a6c17ce96c0a4c649054bb04665d3ffa6\";s:6:\"expire\";s:25:\"2013-12-11T00:15:16-05:00\";}}slim.flash|a:0:{}','2013-12-11T00:19:16-05:00','1013-12-10T23:55:16-05:00'),('pvieptq6dpv279sfkcajvang50','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:133:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/30.0.1599.114 Chrome/30.0.1599.114 Safari/537.36\";s:7:\"EXPIRES\";i:1386308717;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"a0450314af4364ca7fe3cf7d7c1796c462c92e41e36c2e91be8107172eebbe01\";s:6:\"expire\";s:25:\"2013-12-06T00:45:17-05:00\";}}slim.flash|a:0:{}','2013-12-06T00:49:17-05:00','1013-12-06T00:25:17-05:00'),('q6rasfbi49q5hffb25n79vgv55','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:133:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/30.0.1599.114 Chrome/30.0.1599.114 Safari/537.36\";s:7:\"EXPIRES\";i:1385192041;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"b26ff9fb94a0eb32951340480b98844fffb62551267d9bbf36ff7ce503d04b0c\";s:6:\"expire\";s:25:\"2013-11-23T02:34:01-05:00\";}}slim.flash|a:0:{}','2013-11-23T02:38:01-05:00','1013-11-23T02:14:01-05:00'),('r5kn2clmv42aoquppfbrgq8la0','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:74:\"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:26.0) Gecko/20100101 Firefox/26.0\";s:7:\"EXPIRES\";i:1387344671;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"fe4234ce142c486565c0d53073193dd3c12ec755b6d7a366ce8d88502f5b69dc\";s:6:\"expire\";s:25:\"2013-12-18T00:31:11-05:00\";}}slim.flash|a:0:{}','2013-12-18T00:35:11-05:00','1013-12-18T00:11:11-05:00'),('r9cq4hvgv1rluaamqsnccdd0k0','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:133:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/30.0.1599.114 Chrome/30.0.1599.114 Safari/537.36\";s:7:\"EXPIRES\";i:1386473905;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"eabde7b72ff30107e7eabff4991328800349ff56fe03d581a391abf8c4e9cb70\";s:6:\"expire\";s:25:\"2013-12-07T22:38:25-05:00\";}}slim.flash|a:0:{}','2013-12-07T22:42:25-05:00','1013-12-07T22:18:26-05:00'),('rgvontqfs2v1getu81988f2js6','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:74:\"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:25.0) Gecko/20100101 Firefox/25.0\";s:7:\"EXPIRES\";i:1385004276;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"db489f3274d08cabe52c62e93d135c4ec3a7b71d1977a3a8dc994d3db4b1c2f3\";s:6:\"expire\";s:25:\"2013-11-20T22:24:36-05:00\";}}slim.flash|a:0:{}','2013-11-20T22:28:36-05:00','1013-11-20T22:04:36-05:00'),('rk0rm8micf097rknitjtns2nq0','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:74:\"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:24.0) Gecko/20100101 Firefox/24.0\";s:7:\"EXPIRES\";i:1384663530;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"bfa5e20c07ef5a271d6f4e3637174147acfba77fa6b27b5f3eb241cd460063c4\";s:6:\"expire\";s:25:\"2013-11-16T23:45:30-05:00\";}}slim.flash|a:0:{}','2013-11-16T23:49:30-05:00','1013-11-16T23:25:30-05:00'),('s67c7rrgc4klhgoids3ju9n240','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:131:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/31.0.1650.63 Chrome/31.0.1650.63 Safari/537.36\";s:7:\"EXPIRES\";i:1387513765;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"fd14e0da4b49b09f9eb16d1bd7723d32ef9efa37b5eb2466ef36e157e11b619d\";s:6:\"expire\";s:25:\"2013-12-19T23:29:25-05:00\";}}slim.flash|a:0:{}','2013-12-19T23:33:25-05:00','1013-12-19T23:09:25-05:00'),('t06ofah8b68rino96oif3cutv4','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:74:\"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:25.0) Gecko/20100101 Firefox/25.0\";s:7:\"EXPIRES\";i:1385850640;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"f7fe1dd83df324aefa76373335e6ea3315d62c935a6b5e348f66a042397cbf71\";s:6:\"expire\";s:25:\"2013-11-30T17:30:40-05:00\";}}slim.flash|a:0:{}','2013-11-30T17:34:40-05:00','1013-11-30T17:10:40-05:00'),('t3p3g8mhn1h7lctkguipuohsc6','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:131:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/31.0.1650.63 Chrome/31.0.1650.63 Safari/537.36\";s:7:\"EXPIRES\";i:1387344217;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"36ebc990c3b96440bc7cacce6975099062221e1196e500496c38f0d72f77f635\";s:6:\"expire\";s:25:\"2013-12-18T00:23:37-05:00\";}}slim.flash|a:0:{}','2013-12-18T00:27:37-05:00','1013-12-18T00:03:37-05:00'),('t77ufh79sf7jvoj77bmfpp2fb6','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:131:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/31.0.1650.63 Chrome/31.0.1650.63 Safari/537.36\";s:7:\"EXPIRES\";i:1387763434;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"b9650be08aa070cc72e2bb265ee0301f8563f627cec1960d657d64fe22424ec9\";s:6:\"expire\";s:25:\"2013-12-22T20:50:34-05:00\";}}slim.flash|a:0:{}uid|i:2;username|s:28:\"invited-guest@thejackmag.com\";loggedIn|b:1;','2013-12-22T20:54:34-05:00','1013-12-22T20:30:34-05:00'),('tf10el9aums82o2842j59uhhe3','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:131:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/31.0.1650.63 Chrome/31.0.1650.63 Safari/537.36\";s:7:\"EXPIRES\";i:1387763695;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"f1a164e1a309d18191846a51b7f3846027e25659b4c6fd6ab7bd0a1b3473738d\";s:6:\"expire\";s:25:\"2013-12-22T20:54:55-05:00\";}}uid|i:2;username|s:28:\"invited-guest@thejackmag.com\";loggedIn|b:1;slim.flash|a:0:{}','2013-12-22T20:58:55-05:00','1013-12-22T20:34:55-05:00'),('v4evj1h2aukg0mopafs7h1p6s2','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:131:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/31.0.1650.63 Chrome/31.0.1650.63 Safari/537.36\";s:7:\"EXPIRES\";i:1387763979;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"82b176a39049334ab3bdfea61522730d5978a45dc244a5250853fac265ac1065\";s:6:\"expire\";s:25:\"2013-12-22T20:59:39-05:00\";}}uid|i:2;username|s:28:\"invited-guest@thejackmag.com\";loggedIn|b:1;slim.flash|a:0:{}','2013-12-22T21:03:39-05:00','1013-12-22T20:39:40-05:00'),('vikd0aa4tchqgha0b8i52fhdb7','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:74:\"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:25.0) Gecko/20100101 Firefox/25.0\";s:7:\"EXPIRES\";i:1385927646;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"b974457b8d6cbbb74e20ee3eb38fcebd76c630192b37f58cec37b87796aacb7f\";s:6:\"expire\";s:25:\"2013-12-01T14:54:06-05:00\";}}slim.flash|a:0:{}','2013-12-01T14:58:06-05:00','1013-12-01T14:34:06-05:00'),('vts40krsoi3sf3b2f9rsangj06','sses|a:4:{s:9:\"IPaddress\";s:9:\"127.0.0.1\";s:10:\"hostDomain\";s:0:\"\";s:9:\"userAgent\";s:133:\"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/30.0.1599.114 Chrome/30.0.1599.114 Safari/537.36\";s:7:\"EXPIRES\";i:1385943639;}ulNonces|a:1:{s:14:\"ulSessionToken\";a:2:{s:4:\"code\";s:64:\"2dc6f16bff53622b2be0b9abe106edf9ddbb8a51e4deeaec56ae88ca84d6f673\";s:6:\"expire\";s:25:\"2013-12-01T19:20:39-05:00\";}}slim.flash|a:0:{}','2013-12-01T19:24:39-05:00','1013-12-01T19:00:39-05:00');
/*!40000 ALTER TABLE `ul_sessions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-12-23 21:40:22
